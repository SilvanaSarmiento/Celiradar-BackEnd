import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Consejo } from './consejo.entity';

@Injectable()
export class ConsejosService {
  constructor(
    @InjectRepository(Consejo)
    private consejoRepo: Repository<Consejo>,
  ) {}

  findAll(): Promise<Consejo[]> {
    return this.consejoRepo.find({ relations: ['usuario'] });
  }
}
