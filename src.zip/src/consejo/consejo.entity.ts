import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from 'typeorm';
import { Usuario } from '../usuario/usuario.entity';


@Entity()
export class Consejo {
  @PrimaryGeneratedColumn()
  id_consejo: number;

  @Column()
  titulo:string;

  @Column('text')
  texto: string;

  // Relaciones
  @ManyToOne(() => Usuario, (usuario) => usuario.consejos, { onDelete: 'CASCADE' })
  usuario: Usuario;
}