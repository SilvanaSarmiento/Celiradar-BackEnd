import { Controller, Get } from '@nestjs/common';
import { ConsejosService } from './consejos.service';
import { Consejo } from './consejo.entity';

@Controller('consejos')
export class ConsejosController {
  constructor(private consejosService: ConsejosService) {}

  @Get()
  findAll(): Promise<Consejo[]> {
    return this.consejosService.findAll();
  }
}
