export class RegistroUsuarioDto {
  nombre: string;
  email: string;
  password: string;
}
