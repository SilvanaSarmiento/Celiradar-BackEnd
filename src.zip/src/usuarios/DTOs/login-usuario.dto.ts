export class LoginUsuarioDto {
  email: string;
  password: string;
}
